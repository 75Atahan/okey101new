#!/usr/bin/env bash
# Luna101 sunucu kurulumu.
# Taze bir Ubuntu 22.04 / 24.04 sunucuda, root olarak çalıştırılır:
#   bash deploy/kurulum.sh luna101.com.tr senin@eposta.com
set -euo pipefail

ALAN="${1:-luna101.com.tr}"
EPOSTA="${2:?Kullanım: bash deploy/kurulum.sh luna101.com.tr senin@eposta.com}"
UYGULAMA=/opt/luna101
KAYNAK="$(cd "$(dirname "$0")/.." && pwd)"

[ "$(id -u)" -eq 0 ] || { echo "Bu betik root olarak çalıştırılmalı."; exit 1; }

echo "==> 1/6 Paketler kuruluyor"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl unzip nginx certbot python3-certbot-nginx ufw
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "==> 2/6 Oyun dosyaları /opt/luna101 klasörüne kopyalanıyor"
id luna >/dev/null 2>&1 || useradd --system --home "$UYGULAMA" --shell /usr/sbin/nologin luna
mkdir -p "$UYGULAMA"
cp -r "$KAYNAK"/. "$UYGULAMA"/
rm -rf "$UYGULAMA/deploy" "$UYGULAMA"/*.zip
cd "$UYGULAMA"
npm install --omit=dev
chown -R luna:luna "$UYGULAMA"

echo "==> 3/6 Oyun servisi (kendiliğinden açılır, çökerse yeniden başlar)"
cat > /etc/systemd/system/luna101.service <<'UNIT'
[Unit]
Description=Luna101 Okey
After=network.target

[Service]
User=luna
WorkingDirectory=/opt/luna101
Environment=PORT=3000
Environment=NODE_ENV=production
ExecStart=/usr/bin/node server.mjs
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now luna101
sleep 2
curl -fsS http://127.0.0.1:3000/health >/dev/null && echo "Oyun servisi çalışıyor."

echo "==> 4/6 Nginx (web sunucusu) ayarı"
cat > /etc/nginx/sites-available/luna101 <<'NGINX'
server {
  listen 80;
  server_name ALAN_ADI www.ALAN_ADI;

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
  }
}
NGINX
sed -i "s/ALAN_ADI/$ALAN/g" /etc/nginx/sites-available/luna101
ln -sf /etc/nginx/sites-available/luna101 /etc/nginx/sites-enabled/luna101
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

echo "==> 5/6 Güvenlik duvarı (yalnızca SSH, 80, 443 açık)"
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

echo "==> 6/6 HTTPS sertifikası (kamera ve mikrofon için zorunlu)"
SUNUCU_IP="$(curl -4 -fsS https://ifconfig.me || true)"
ALAN_IP="$(getent ahostsv4 "$ALAN" | awk 'NR==1{print $1}' || true)"
if [ -n "$SUNUCU_IP" ] && [ "$SUNUCU_IP" = "$ALAN_IP" ]; then
  certbot --nginx -d "$ALAN" -d "www.$ALAN" --non-interactive --agree-tos -m "$EPOSTA" --redirect
  echo
  echo "KURULUM TAMAM: https://$ALAN"
else
  echo
  echo "Oyun şu an http://$SUNUCU_IP adresinde çalışıyor ama HTTPS henüz kurulamadı."
  echo "Sebep: $ALAN adresi bu sunucuya ($SUNUCU_IP) yönlenmiyor (şu an: ${ALAN_IP:-bulunamadı})."
  echo "Alan adının DNS panelinde A kaydını $SUNUCU_IP yapın, 10-30 dakika bekleyin, sonra şunu çalıştırın:"
  echo "  certbot --nginx -d $ALAN -d www.$ALAN --agree-tos -m $EPOSTA --redirect"
fi
