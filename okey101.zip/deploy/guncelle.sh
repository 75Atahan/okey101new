#!/usr/bin/env bash
# Oyunu yeni sürümle günceller (yeni zip'i açtıktan sonra, açılan klasörün içinden):
#   bash deploy/guncelle.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Bu betik root olarak çalıştırılmalı."; exit 1; }
UYGULAMA=/opt/luna101
KAYNAK="$(cd "$(dirname "$0")/.." && pwd)"
cp -r "$KAYNAK"/. "$UYGULAMA"/
rm -rf "$UYGULAMA/deploy" "$UYGULAMA"/*.zip
cd "$UYGULAMA"
npm install --omit=dev
chown -R luna:luna "$UYGULAMA"
systemctl restart luna101
sleep 2
curl -fsS http://127.0.0.1:3000/health >/dev/null && echo "Güncellendi, oyun çalışıyor."
